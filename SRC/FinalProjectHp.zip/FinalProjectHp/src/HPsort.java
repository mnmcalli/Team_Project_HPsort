//Team 4
// Author Mikki McAllister
package HarryPotter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//package HarryPotter;
/**
 *
 * @author jessicasmither
 */
public class HPsort {
    
//    public static void main(String[] args) {
//            
////            System.out.println("WD " + System.getProperties());
////            System.out.println("");
////		
//            Quiz HPquiz = new Quiz(9);       //Question(String q, String gA, String rA, String hA, String sA)
//            HPquiz.readQuestion("questions.txt", "gAnswers.txt", "hAnswers.txt", "rAnswers.txt", "sAnswers.txt");
//            HPquiz.display();
//            HPquiz.score();
//	}
	

}
